<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<?php
function pyramid_image_url($path, $asset_path, $base_path)
{
	return strpos($path, 'upload/') === 0 ? $base_path . '/' . $path : $asset_path . '/' . $path;
}
?>
<section id="beranda" class="infetech-banner-area infetech-banner-slide">
	<div class="infetech-banner-slide-active item-1 pyramid-hero-panel">
		<div class="pyramid-hero-collage" aria-hidden="true">
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/activity-kantor-13.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/activity-kantor-14.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/BERSAMA MEREKA/diskusi-session-with-erzora-kosmetik.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO CLIENT/20260202_144945.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/makan-w-tim-2.jpg');"></span>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="infetech-banner-content">
						<h4 class="title" data-animation="fadeInDown" data-delay=".1s">Company Profile <?php echo $company['name']; ?></h4>
						<h1 class="" data-animation="fadeInLeft" data-delay=".3s">IT Solutions <img src="<?php echo $asset_path; ?>/images/banner-icon.png" alt=""> <br> Services</h1>
						<a class="main-btn" data-animation="fadeInUp" data-delay=".6s" href="#tentang">Kenali Kami</a>
						<img class="banner-arrow" data-animation="fadeInRight" data-delay=".9s" src="<?php echo $asset_path; ?>/images/banner-arrow.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="infetech-banner-slide-active item-2 pyramid-hero-panel">
		<div class="pyramid-hero-collage" aria-hidden="true">
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/BERSAMA MEREKA/diskusi-session-with-erzora-kosmetik.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO CLIENT/web-profile-mismuja.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO CLIENT/sistem-homestay-probolinggo.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/activity-kantor-11.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO CLIENT/sarpras-smkn1lumajang.jpg');"></span>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="infetech-banner-content">
						<h4 class="title" data-animation="fadeInDown" data-delay=".1s">Website, Aplikasi, dan Sistem Digital</h4>
						<h1 class="" data-animation="fadeInLeft" data-delay=".3s">Digital <img src="<?php echo $asset_path; ?>/images/banner-icon.png" alt=""> <br> Solutions</h1>
						<a class="main-btn" data-animation="fadeInUp" data-delay=".6s" href="#layanan">Lihat Layanan</a>
						<img class="banner-arrow" data-animation="fadeInRight" data-delay=".9s" src="<?php echo $asset_path; ?>/images/banner-arrow.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="infetech-banner-slide-active item-3 pyramid-hero-panel">
		<div class="pyramid-hero-collage" aria-hidden="true">
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/makan-w-tim.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/BERSAMA MEREKA/kunjungan-supervisor-upskilling-BOE-malang.PNG');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/BERSAMA MEREKA/meeting-website-profile-ptkmi.PNG');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/activity-kantor-12.jpg');"></span>
			<span style="background-image: url('<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO CLIENT/20250819_164414.jpg');"></span>
		</div>
		<div class="container">
			<div class="row">
				<div class="col-lg-12">
					<div class="infetech-banner-content">
						<h4 class="title" data-animation="fadeInDown" data-delay=".1s">Tim, Legalitas, Lokasi, dan Partner</h4>
						<h1 class="" data-animation="fadeInLeft" data-delay=".3s">Trusted <img src="<?php echo $asset_path; ?>/images/banner-icon.png" alt=""> <br> Company</h1>
						<a class="main-btn" data-animation="fadeInUp" data-delay=".6s" href="#legalitas">Lihat Profil</a>
						<img class="banner-arrow" data-animation="fadeInRight" data-delay=".9s" src="<?php echo $asset_path; ?>/images/banner-arrow.png" alt="">
					</div>
				</div>
			</div>
		</div>
	</div>
</section>

<section id="tentang" class="infetech-about-area pyramid-section-compact">
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="infetech-about-thumb pyramid-about-gallery animated wow fadeInLeft" data-wow-duration="1000ms" data-wow-delay="0ms">
					<img class="pyramid-about-photo-main" src="<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/FOTO TIM/activity-kantor-13.jpg" alt="Tim <?php echo $company['name']; ?>">
					<img class="thumb pyramid-about-photo-secondary" src="<?php echo $asset_path; ?>/img_pyramid/ASSET WEB PROFILE/BERSAMA MEREKA/diskusi-session-with-erzora-kosmetik.jpg" alt="Kegiatan bersama klien">
					<img class="pyramid-about-corner-logo" src="<?php echo $asset_path; ?>/img_pyramid/logo/LOGO PYRAMID SAJA.png" alt="Logo Pyramid">
				</div>
			</div>
			<div class="col-lg-6">
				<div class="infetech-about-content">
					<span>Tentang Perusahaan</span>
					<h3 class="title">Piramidsoft hadir sebagai partner teknologi untuk digitalisasi bisnis.</h3>
					<p>Piramidsoft berfokus pada pengembangan solusi digital yang membantu operasional bisnis menjadi lebih efisien, profesional, dan siap berkembang. Informasi resmi mengenai tahun berdiri, badan hukum, dan profil legal akan dilengkapi setelah data final tersedia.</p>
					<div class="row">
						<div class="col-md-6">
							<div class="about-card">
								<div class="icon">
									<img src="<?php echo $asset_path; ?>/images/icon/icon-1.png" alt="">
								</div>
								<div class="content">
									<h4 class="title">Digitalisasi Bisnis</h4>
								</div>
							</div>
						</div>
						<div class="col-md-6">
							<div class="about-card">
								<div class="icon">
									<img src="<?php echo $asset_path; ?>/images/icon/icon-2.png" alt="">
								</div>
								<div class="content">
									<h4 class="title">Solusi Custom</h4>
								</div>
							</div>
						</div>
					</div>
					<ul>
						<li><i class="fas fa-check-circle"></i> Website company profile, landing page, dan sistem informasi.</li>
						<li><i class="fas fa-check-circle"></i> Aplikasi web/mobile, POS, ERP custom, dan integrasi sistem.</li>
						<li><i class="fas fa-check-circle"></i> Maintenance, pengembangan fitur, dan konsultasi teknologi.</li>
					</ul>
					<a href="<?php echo site_url('profil/sejarah'); ?>" class="main-btn">Selengkapnya Tentang Pyramid</a>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="infetech-feature-area pyramid-section-compact">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="section-title section-title-2">
					<span>Keunggulan Pyramid</span>
					<h4 class="title">Pendekatan teknologi yang fokus pada kebutuhan bisnis.</h4>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="section-title pl-100">
					<p>Pyramid membantu bisnis, institusi, dan organisasi membangun solusi digital yang relevan, mudah digunakan, dan dapat dikembangkan.</p>
				</div>
			</div>
		</div>
		<div class="row justify-content-center">
			<?php foreach ($advantages as $index => $advantage) : ?>
				<div class="col-lg-3 col-md-6">
					<div class="single-infetech-feature-item">
						<div class="icon">
							<img src="<?php echo $asset_path; ?>/images/icon/service-icon-<?php echo ($index % 3) + 1; ?>.png" alt="<?php echo $advantage['title']; ?>">
						</div>
						<div class="content">
							<h4 class="title"><a href="#"><?php echo $advantage['title']; ?></a></h4>
							<p><?php echo $advantage['description']; ?></p>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section id="layanan" class="infetech-service-area pyramid-section-compact">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-8">
				<div class="section-title text-center mb-55">
					<span>Layanan Kami</span>
					<h4 class="title">Solusi digital untuk kebutuhan bisnis, lembaga, dan brand yang ingin berkembang.</h4>
				</div>
			</div>
		</div>
		<div class="row pyramid-service-row">
			<?php foreach ($services as $index => $service) : ?>
				<div class="col-xl-3 col-lg-6 col-md-6">
					<div class="single-infetech-serice-item pyramid-service-card animated wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="<?php echo $index * 200; ?>ms">
						<div class="thumb">
							<img src="<?php echo pyramid_image_url($service['image'], $asset_path, $base_path); ?>" alt="<?php echo $service['title']; ?>">
						</div>
						<div class="content">
							<div class="icon">
								<img src="<?php echo $asset_path; ?>/images/icon/<?php echo $service['icon']; ?>" alt="">
							</div>
							<h3 class="title"><a href="<?php echo $company['service_url']; ?>" target="_blank" rel="noopener noreferrer"><?php echo $service['title']; ?></a></h3>
							<p class="pyramid-card-text"><?php echo $service['description']; ?></p>
							<a class="pyramid-small-btn" href="<?php echo $company['service_url']; ?>" target="_blank" rel="noopener noreferrer">Selengkapnya</a>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<section class="infetech-feature-area pyramid-section-compact pyramid-technology-area">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-6">
				<div class="section-title section-title-2">
					<span>Teknologi</span>
					<h4 class="title">Membangun masa depan dengan teknologi terkini.</h4>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="section-title pl-100">
					<p>Pyramid menggunakan teknologi web, mobile, cloud, dan payment integration untuk memastikan solusi berjalan cepat, aman, dan mudah dikembangkan.</p>
				</div>
			</div>
		</div>
		<div class="row justify-content-center pyramid-equal-row">
			<?php foreach ($tech_groups as $tech) : ?>
				<div class="col-lg-3 col-md-6">
					<div class="single-infetech-feature-item pyramid-equal-card pyramid-tech-card">
						<div class="content">
							<h4 class="title"><a href="#"><?php echo $tech['title']; ?></a></h4>
							<p><?php echo $tech['description']; ?></p>
							<div class="pyramid-tech-icons">
								<?php for ($i = 1; $i <= min($tech['total'], 4); $i++) : ?>
									<img src="<?php echo $asset_path; ?>/img_pyramid/<?php echo $tech['folder']; ?>/<?php echo $i; ?>.png" alt="<?php echo $tech['title']; ?>">
								<?php endfor; ?>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</section>

<div id="legalitas" class="infetech-cta-area pyramid-legal-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="infetech-cta-box pyramid-legal-box animated wow fadeIn" data-wow-duration="1000ms" data-wow-delay="300ms">
					<div class="cta-content">
						<span class="pyramid-legal-label">Legalitas Perusahaan</span>
						<h2 class="title"><?php echo $company['legal_name']; ?></h2>
						<p>Informasi legalitas perusahaan ditampilkan pada beranda sebagai bagian dari pengenalan resmi Pyramid.</p>
						<ul>
							<li><i class="fas fa-check-circle"></i> Identitas badan usaha: <?php echo $company['legal_name']; ?>.</li>
							<li><i class="fas fa-check-circle"></i> Informasi dan dokumen resmi dapat dikonfirmasi melalui kontak perusahaan.</li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</div>
</div>

<div id="brand" class="infetech-sponser-area">
	<div class="container">
		<div class="row infetech-sponser-slide">
			<?php foreach ($brands as $brand) : ?>
				<div class="col-lg-3">
					<div class="infetech-sponser-item">
						<img src="<?php echo $asset_path; ?>/<?php echo $brand; ?>" alt="Brand client Piramidsoft">
					</div>
				</div>
			<?php endforeach; ?>
		</div>
	</div>
</div>

<!-- <section class="infetech-testimonial-area">
	<div class="container">
		<div class="row">
			<div class="col-lg-12">
				<div class="section-title text-center mb-55">
					<span>Profil Perusahaan</span>
					<h3 class="title">What They’re Talking?</h3>
				</div>
			</div>
		</div>
		<div class="row infetech-testimonial-slide">
			<div class="col-lg-6">
				<div class="single-testimonial-box">
					<div class="single-testimonial-user">
						<div class="thumb">
							<img src="<?php echo $asset_path; ?>/images/testimonial-thumb-1.png" alt="">
						</div>
						<div class="user-content">
							<h5 class="title">Piramidsoft</h5>
							<span>Digital Partner</span>
							<img src="<?php echo $asset_path; ?>/images/testimonial-shape.png" alt="">
						</div>
					</div>
					<div class="single-testimonial-item">
						<ul>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
						</ul>
						<p>Piramidsoft membantu klien mengenalkan profil perusahaan, membangun sistem digital, dan mengelola kebutuhan teknologi secara profesional.</p>
					</div>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="single-testimonial-box">
					<div class="single-testimonial-user">
						<div class="thumb">
							<img src="<?php echo $asset_path; ?>/images/testimonial-thumb-2.png" alt="">
						</div>
						<div class="user-content">
							<h5 class="title">Layanan Digital</h5>
							<span>Website & System</span>
							<img src="<?php echo $asset_path; ?>/images/testimonial-shape.png" alt="">
						</div>
					</div>
					<div class="single-testimonial-item">
						<ul>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
							<li><i class="fas fa-star"></i></li>
						</ul>
						<p>Detail brand partner, legalitas, visi-misi, dan struktur organisasi akan dilengkapi setelah data final diberikan.</p>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> -->

<section id="tim" class="infetech-team-area pyramid-section-compact">
	<div class="container">
		<div class="row align-items-center mb-50">
			<div class="col-lg-6">
				<div class="section-title">
					<span>Tim Pyramid</span>
					<h4 class="title">Orang-orang yang mengelola pengembangan dan pendampingan digital.</h4>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="section-title pl-100">
					<p>Tim Pyramid bekerja bersama dalam pengembangan, implementasi, dan pendampingan solusi digital untuk klien.</p>
				</div>
			</div>
		</div>
		<div class="row">
			<?php if (empty($teams)) : ?>
				<div class="col-lg-12">
					<div class="pyramid-meta-list text-center">
						<p>Data tim belum tersedia. Silakan tambahkan anggota tim melalui halaman admin.</p>
					</div>
				</div>
			<?php endif; ?>
			<?php foreach (array_slice($teams, 0, 3) as $index => $team) : ?>
				<div class="col-lg-4 col-md-6">
					<div class="single-tema-item animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="<?php echo $index * 300; ?>ms">
						<div class="top-line"></div>
						<div class="thumb">
							<img src="<?php echo pyramid_image_url($team['image'], $asset_path, $base_path); ?>" alt="<?php echo $team['name']; ?>">
						</div>
						<div class="content">
							<h4 class="title"><?php echo $team['name']; ?></h4>
							<span><?php echo $team['position']; ?></span>
							<?php if (!empty($team['linkedin']) || !empty($team['instagram'])) : ?>
								<div class="share-icon">
									<i class="fas fa-share-alt"></i>
									<ul>
										<?php if (!empty($team['linkedin'])) : ?>
											<li><a href="<?php echo $team['linkedin']; ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin-in"></i></a></li>
										<?php endif; ?>
										<?php if (!empty($team['instagram'])) : ?>
											<li><a href="<?php echo $team['instagram']; ?>" target="_blank" rel="noopener noreferrer"><i class="fab fa-instagram"></i></a></li>
										<?php endif; ?>
									</ul>
								</div>
							<?php endif; ?>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<div class="row">
			<div class="col-lg-12 text-center mt-40">
				<a class="main-btn pyramid-home-outline-btn" href="<?php echo site_url('profil/tim'); ?>">Lihat Seluruh Tim</a>
			</div>
		</div>
	</div>
</section>

<section class="infetech-blog-area pyramid-section-compact">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-7">
				<div class="section-title text-center mb-55">
					<span>Kegiatan</span>
					<h4 class="title">Beberapa aktivitas dan proses kerja Piramidsoft bersama klien.</h4>
				</div>
			</div>
		</div>
		<div class="row">
			<?php if (empty($activities)) : ?>
				<div class="col-lg-12">
					<div class="pyramid-meta-list text-center">
						<p>Belum ada kegiatan yang dipublikasikan.</p>
					</div>
				</div>
			<?php endif; ?>
			<?php foreach (array_slice($activities, 0, 3) as $index => $activity) : ?>
				<div class="col-lg-4 col-md-6">
					<div class="single-blog-item animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="<?php echo $index * 300; ?>ms">
						<div class="thumb">
							<a href="<?php echo site_url('kegiatan/detail/' . $activity['slug']); ?>"><img src="<?php echo pyramid_image_url($activity['image'], $asset_path, $base_path); ?>" alt="<?php echo $activity['title']; ?>"></a>
							<span><?php echo $activity['category']; ?></span>
						</div>
						<div class="content">
							<div class="blog-meta">
								<ul>
									<li><i class="fal fa-user-circle"></i> <?php echo $activity['client']; ?></li>
									<li><i class="fal fa-calendar-alt"></i> <?php echo date('d M Y', strtotime($activity['date_iso'])); ?></li>
								</ul>
								<h4 class="title"><a href="<?php echo site_url('kegiatan/detail/' . $activity['slug']); ?>"><?php echo $activity['title']; ?></a></h4>
								<a href="<?php echo site_url('kegiatan/detail/' . $activity['slug']); ?>">Lihat Detail</a>
							</div>
						</div>
					</div>
				</div>
			<?php endforeach; ?>
		</div>
		<div class="row">
			<div class="col-lg-12 text-center mt-40">
				<a class="main-btn pyramid-home-outline-btn" href="<?php echo site_url('kegiatan'); ?>">Lihat Semua Kegiatan</a>
			</div>
		</div>
	</div>
</section>

<!-- <section class="infetech-video-area">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-7">
				<div class="video-content animated wow fadeInLeft" data-wow-duration="1500ms" data-wow-delay="0ms">
					<div class="play-btn">
						<a class="video-popup" href="#"><i class="fas fa-play"></i></a>
					</div>
					<span>Ringkasan Perusahaan</span>
					<h2 class="title">Save Time and Money with a Top IT Solution Agency</h2>
				</div>
			</div>
			<div class="col-lg-5">
				<div class="video-content-wrapper animated wow fadeIn" data-wow-duration="1500ms" data-wow-delay="300ms">
					<div class="video-content-box">
						<div class="item">
							<h4 class="title">3+</h4>
							<span>Layanan utama <br> tersedia</span>
						</div>
					</div>
					<div class="video-content-box item-2 animated wow fadeIn" data-wow-duration="1000ms" data-wow-delay="600ms">
						<div class="item">
							<h4 class="title">6+</h4>
							<span>Kategori solusi <br> digital</span>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> -->

<!-- <section class="infetech-blog-area pt-115 pb-120">
	<div class="container">
		<div class="row justify-content-center">
			<div class="col-lg-6">
				<div class="section-title text-center">
					<span>Informasi Perusahaan</span>
					<h4 class="title">News & Articles</h4>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col-lg-4 col-md-6">
				<div class="single-blog-item animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="0ms">
					<div class="thumb">
						<a href="#tentang"><img src="<?php echo $asset_path; ?>/images/blog-1.jpg" alt=""></a>
						<span>Profil</span>
					</div>
					<div class="content">
						<div class="blog-meta">
							<ul>
								<li><i class="fal fa-user-circle"></i> by Piramidsoft</li>
								<li><i class="fal fa-comments"></i> Company</li>
							</ul>
							<h4 class="title"><a href="#tentang">Profil perusahaan dan sejarah berdiri.</a></h4>
							<a href="#tentang">Read More</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6">
				<div class="single-blog-item animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="300ms">
					<div class="thumb">
						<a href="#legalitas"><img src="<?php echo $asset_path; ?>/images/blog-2.jpg" alt=""></a>
						<span>Legal</span>
					</div>
					<div class="content">
						<div class="blog-meta">
							<ul>
								<li><i class="fal fa-user-circle"></i> by Piramidsoft</li>
								<li><i class="fal fa-comments"></i> Legalitas</li>
							</ul>
							<h4 class="title"><a href="#legalitas">Legalitas, lokasi, dan struktur organisasi.</a></h4>
							<a href="#legalitas">Read More</a>
						</div>
					</div>
				</div>
			</div>
			<div class="col-lg-4 col-md-6">
				<div class="single-blog-item animated wow fadeInUp" data-wow-duration="1500ms" data-wow-delay="600ms">
					<div class="thumb">
						<a href="#brand"><img src="<?php echo $asset_path; ?>/images/blog-3.jpg" alt=""></a>
						<span>Brand</span>
					</div>
					<div class="content">
						<div class="blog-meta">
							<ul>
								<li><i class="fal fa-user-circle"></i> by Piramidsoft</li>
								<li><i class="fal fa-comments"></i> Partner</li>
							</ul>
							<h4 class="title"><a href="#brand">Brand partner yang bekerja sama.</a></h4>
							<a href="#brand">Read More</a>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
</section> -->

<!-- <section class="infetech-cta-2-area pt-100 pb-100">
	<div class="container">
		<div class="row align-items-center">
			<div class="col-lg-9">
				<div class="cta-content">
					<p>Layanan lengkap akan diarahkan ke website jasa website murah.</p>
					<h2 class="title">Looking for the Best IT Business Solutions?</h2>
				</div>
			</div>
			<div class="col-lg-3">
				<div class="cta-btn text-right">
					<a class="main-btn" href="<?php echo $company['service_url']; ?>">Learn More</a>
				</div>
			</div>
		</div>
	</div>
</section> -->
